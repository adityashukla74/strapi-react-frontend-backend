module.exports = {
  jwtSecret: process.env.JWT_SECRET || '901545a4-5417-4fed-841d-c05d1cfcf36e'
};